package com.example.abc.homeautomation;

/**
 * Created by AAC-SG-LAP on 16-Mar-16.
 */
public class ProjectConfig {
    public static String MobilenNumber = "7219809971";
    public static final String MAIN_URL = "http://192.168.1.21:8080/Home_Automation/rest/home/";

    public static final String savestaus = MAIN_URL + "save";
    public static final String Login = MAIN_URL + "login";
    public static final String Register = MAIN_URL + "saveuser";
    public static final String updatelocation = MAIN_URL + "";
}
